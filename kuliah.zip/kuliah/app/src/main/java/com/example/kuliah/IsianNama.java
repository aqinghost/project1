package com.example.kuliah;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class IsianNama extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.actifity_isian_nama);
    }
}
